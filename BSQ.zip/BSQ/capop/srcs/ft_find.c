/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/27 19:05:06 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:13:49 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_find_square(char **matrix, int **rez, int n, int m)
{
	int i;
	int j;
	int max;
	int max_i;
	int max_j;

	i = 0;
	max = 0;
	while (i < n)
	{
		j = 0;
		while (j < m)
		{
			if (rez[i][j] > max)
			{
				max = rez[i][j];
				max_i = i;
				max_j = j;
			}
			j++;
		}
		i++;
	}
	ft_fill_x(matrix, max, max_i, max_j);
}

void	ft_find_matrix_square(char **matrix, char map[3])
{
	int i;
	int	**rez;

	rez = ft_make_matrix(ft_atoii(matrix[0]), ft_strlen(matrix[1]));
	ft_fill_matrix(matrix + 1, rez, ft_atoii(matrix[0]), map);
	ft_find_square(matrix, rez, ft_atoii(matrix[0]), ft_strlen(matrix[1]));
	ft_print_matrix(matrix + 1);
	i = 0;
	while (i < ft_atoii(matrix[0]))
	{
		free(rez[i]);
		i++;
	}
	free(rez);
}
