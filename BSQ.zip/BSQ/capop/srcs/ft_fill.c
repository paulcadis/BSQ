/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fill.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/27 19:03:59 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:13:32 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_fill_matrix_rest(char **matrix, int **rez, int n, char map[3])
{
	int i;
	int j;
	int m;

	m = ft_strlen(matrix[0]);
	i = 1;
	while (i < n)
	{
		j = 1;
		while (j < m)
		{
			if (matrix[i][j] == map[0])
				rez[i][j] = 1 + ft_cmp(rez[i - 1][j], rez[i][j - 1],
						rez[i - 1][j - 1]);
			else
				rez[i][j] = 0;
			j++;
		}
		i++;
	}
}

void	ft_fill_matrix(char **matrix, int **rez, int n, char map[3])
{
	int	i;
	int	m;

	m = ft_strlen(matrix[0]);
	i = 0;
	while (i < n)
	{
		if (matrix[i][0] == map[0])
			rez[i][0] = 1;
		else
			rez[i][0] = 0;
		i++;
	}
	i = 0;
	while (i < m)
	{
		if (matrix[0][i] == map[0])
			rez[0][i] = 1;
		else
			rez[0][i] = 0;
		i++;
	}
	ft_fill_matrix_rest(matrix, rez, n, map);
}

void	ft_fill_x(char **matrix, int max, int max_i, int max_j)
{
	int		i;
	int		j;
	char	c;
	char	u;
	char	**aux;

	aux = matrix + 1;
	c = matrix[0][ft_strlen(matrix[0]) - 3];
	u = matrix[0][ft_strlen(matrix[0]) - 1];
	i = max_i;
	while (i > max_i - max)
	{
		j = max_j;
		while (j > max_j - max)
		{
			if (aux[i][j] == c)
				aux[i][j] = u;
			j--;
		}
		i--;
	}
}
