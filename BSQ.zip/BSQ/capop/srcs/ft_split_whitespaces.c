/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/16 09:37:08 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 15:57:42 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_numbers_of_words(char *str)
{
	int	size;
	int	index;

	if (str == '\0')
		return (0);
	index = 0;
	while (str[index] == '\n'
			&& str[index] != '\0')
		index++;
	if (str[index] == '\0')
		return (0);
	size = 1;
	while (str[index] != '\0')
	{
		if ((str[index] == '\n' || str[index] == '\t')
				&& (str[index + 1] != '\n'
					&& str[index + 1] != '\t' && str[index + 1] != '\0'))
			size++;
		index++;
	}
	return (size);
}

int		ft_word_size(char *str)
{
	int size;
	int index;

	index = 0;
	size = 0;
	while (str[index] != '\n' && str[index] != '\0')
	{
		size++;
		index++;
	}
	return (size);
}

void	ft_create_matrix(int i, int index, char *str, char **rez)
{
	int j;
	int aux;

	while (str[index] != '\0')
	{
		if (str[index] != '\0')
		{
			j = 0;
			aux = ft_word_size(&str[index]);
			rez[i] = (char*)malloc(sizeof(char) * (aux + 1));
			while (str[index] != '\n' && str[index] != '\0')
			{
				rez[i][j] = str[index];
				j++;
				index++;
			}
			rez[i][j] = '\0';
			i++;
		}
		index++;
	}
}

char	**ft_split_whitespaces(char *str)
{
	char	**rez;
	int		size;
	int		index;
	int		i;

	if (ft_numbers_of_words(str) == 0)
	{
		rez = (char**)malloc(sizeof(char) * 1);
		rez[0] = 0;
	}
	else
	{
		size = ft_numbers_of_words(str) + 1;
		rez = (char**)malloc(sizeof(int*) * size);
		index = 0;
		i = 0;
		ft_create_matrix(i, index, str, rez);
		rez[size - 1] = 0;
	}
	return (rez);
}
