/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 15:52:23 by capop             #+#    #+#             */
/*   Updated: 2016/07/11 17:12:22 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_check_sign(char *str, int *sign, int *i)
{
	if (str[*i] == '-')
	{
		*sign = -1;
		*i = *i + 1;
	}
	else if (str[*i] == '+')
		*i = *i + 1;
}

int		ft_atoi(char *str)
{
	long int	nr;
	int			i;
	int			ok;
	int			max_size;
	int			sign;

	max_size = 2147483647;
	i = 0;
	nr = 0;
	ok = 1;
	sign = 1;
	while (str[i] != '\0' && str[i] == ' ')
		i++;
	ft_check_sign(str, &sign, &i);
	while (str[i] >= '0' && str[i] <= '9' && str[i] != '\0')
	{
		nr = nr * 10 + str[i] - '0';
		i++;
	}
	if (nr > max_size)
		return (-1 * (nr - (nr - max_size - 1)));
	return (nr * sign);
}
