/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_help_f.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/27 19:02:31 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:14:06 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_atoii(char *str)
{
	char	*rez;
	int		nb;

	rez = (char *)malloc(sizeof(char) * ft_strlen(str) - 2);
	ft_strncpy(rez, str, ft_strlen(str) - 4);
	nb = ft_atoi(rez);
	free(rez);
	return (nb);
}

int		**ft_make_matrix(int n, int m)
{
	int i;
	int **rez;

	rez = (int **)malloc(sizeof(int *) * n + 1);
	i = 0;
	while (i < n)
	{
		rez[i] = (int *)malloc(sizeof(int) * m + 1);
		i++;
	}
	return (rez);
}

int		ft_cmp(int i, int j, int k)
{
	if (i <= j && i <= k)
		return (i);
	else if (j <= i && j <= k)
		return (j);
	else
		return (k);
}
