/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/25 16:35:02 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 20:08:17 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_is_valid(char **matrix, int n)
{
	int i;

	i = 1;
	if (matrix[0] == 0)
		return (0);
	while (matrix[i])
	{
		if (n != ft_strlen(matrix[i])
				|| ft_strlen(matrix[i]) == 0
				|| matrix[i][0] == '\n'
				|| matrix[i][0] == '\0')
			return (0);
		i++;
	}
	return (1);
}

int		ft_check_character(char c, char map[3])
{
	int i;
	int ok;

	ok = 0;
	i = 0;
	while (i < 3)
	{
		if (map[i] == c)
			ok = 1;
		i++;
	}
	return (ok);
}

int		ft_check_matrix(char **matrix, int n, int m, char map[3])
{
	int i;
	int j;

	i = 0;
	while (i < n)
	{
		j = 0;
		while (j < m)
		{
			if (ft_check_character(matrix[i][j], map) == 0)
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

int		ft_get_lines(char **matrix)
{
	int i;
	int size;

	i = 0;
	size = 0;
	while (matrix[i])
	{
		i++;
		size++;
	}
	return (size);
}

int		ft_validate(char **matrix, char map[3])
{
	map[0] = matrix[0][ft_strlen(matrix[0]) - 3];
	map[1] = matrix[0][ft_strlen(matrix[0]) - 2];
	map[2] = matrix[0][ft_strlen(matrix[0]) - 1];
	if (ft_get_lines(matrix) > 1)
	{
		if (ft_atoii(matrix[0]) != 0
				&& ft_is_valid(matrix, ft_strlen(matrix[1]))
				&& ft_check_matrix(matrix + 1, ft_atoii(matrix[0]),
					ft_strlen(matrix[1]), map)
				&& matrix[0] != NULL
				&& ft_get_lines(matrix) == ft_atoii(matrix[0]) + 1)
		{
			return (1);
		}
		else
			return (0);
	}
	else
		return (0);
}
