/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/27 19:07:23 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:13:16 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_open_read(char *filename, char **str)
{
	int fd;

	fd = open(filename, O_RDONLY);
	if (fd < 0)
		return ;
	*str = ft_read(fd);
	close(fd);
}

int		ft_run_matrix(char *filename)
{
	char	*str;
	char	**matrix;
	char	map[3];
	int		i;

	str = NULL;
	ft_open_read(filename, &str);
	matrix = NULL;
	if (str != NULL && str != '\0' && ft_strlen(str) > 3)
	{
		matrix = ft_split_whitespaces(str);
		if (matrix[0] != 0)
			if (ft_validate(matrix, map) == 1)
			{
				ft_find_matrix_square(matrix, map);
				i = -1;
				while (matrix[i++])
					free(matrix[i]);
				free(matrix);
				free(str);
				return (1);
			}
	}
	return (0);
}

char	**ft_create_input_matrix(void)
{
	char	**matrix;
	char	*rez;
	int		size;
	int		index;

	matrix = NULL;
	rez = ft_read_input();
	if (rez != '\0')
		if (ft_strlen(rez) > 3)
		{
			size = ft_atoii(rez);
			if (size != 0)
			{
				matrix = (char **)malloc(sizeof(char*) * (size + 3));
				index = 0;
				matrix[0] = rez;
				while (index++ < size)
				{
					rez = ft_read_input();
					matrix[index] = rez;
				}
				matrix[index] = 0;
			}
		}
	return (matrix);
}

int		ft_run_matrix_input(void)
{
	char	**matrix;
	char	map[3];
	int		i;

	matrix = ft_create_input_matrix();
	if (matrix != NULL)
	{
		if (ft_validate(matrix, map) == 1)
		{
			ft_find_matrix_square(matrix, map);
			i = 0;
			while (matrix[i])
			{
				free(matrix[i]);
				i++;
			}
			free(matrix);
			return (1);
		}
	}
	return (0);
}
