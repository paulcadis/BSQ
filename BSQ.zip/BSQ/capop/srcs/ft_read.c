/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/25 14:26:03 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:15:14 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

char	*ft_realloc(char **rez, int *capacity, int *index)
{
	char	*temp;
	char	*aux;

	*capacity = *capacity * 2;
	temp = (char *)malloc(sizeof(char) * (*capacity));
	ft_strncpy(temp, *rez, *index);
	free(*rez);
	return (temp);
}

char	*ft_read(int fd)
{
	char	*rez;
	int		capacity;
	int		index;
	char	a[10];
	int		ret;

	rez = NULL;
	index = 0;
	capacity = 4;
	ret = read(fd, &a, 9);
	if (ret != 0)
	{
		rez = (char *)malloc(sizeof(char) * capacity);
		while (ret != 0)
		{
			if (index + ret >= capacity)
				rez = ft_realloc(&rez, &capacity, &index);
			ft_strncpy(&rez[index], a, ret);
			index = index + ret;
			ret = read(fd, &a, 9);
		}
		rez[index] = '\0';
	}
	return (rez);
}

char	*ft_read_input(void)
{
	char	a;
	char	*str;
	int		index;
	int		capacity;
	int		ret;

	capacity = 2;
	str = (char *)malloc(sizeof(char) * capacity);
	index = 0;
	ret = read(0, &a, 1);
	while (a != '\n' && ret)
	{
		if (index + 1 >= capacity)
			str = ft_realloc(&str, &capacity, &index);
		str[index] = a;
		index++;
		ret = read(0, &a, 1);
	}
	str[index] = '\0';
	return (str);
}
