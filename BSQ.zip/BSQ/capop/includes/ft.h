/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/16 15:56:18 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:12:24 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <fcntl.h>
# include <unistd.h>
# include <stdlib.h>

void	ft_putchar(char c);
void	ft_putstr(char *str);
int		ft_strcmp(char *s1, char *s2);
int		ft_strlen(char *str);
void	ft_swap(int *a, int *b);
char	**ft_split_whitespaces(char *str);
char	*ft_strcpy(char *dest, char *src);
char	*ft_strncpy(char *dest, char *src, unsigned int n);
char	*ft_realloc(char **rez, int *capacity, int *index);
char	*ft_read(int fd);
int		ft_check_line(char **matrix, int i, int j);
int		ft_check_column(char **matrix, int i, int j);
int		ft_is_valid(char **matrix, int n);
int		ft_atoi(char *str);
int		ft_check_matrix(char **matrix, int n, int m, char map[3]);
int		ft_check_character(char c, char map[3]);
int		ft_get_lines(char **matrix);
int		ft_atoii(char *str);
int		**ft_make_matrix(int n, int m);
int		ft_cmp(int i, int j, int k);
void	ft_fill_matrix_rest(char **matrix, int **rez, int n, char map[3]);
void	ft_fill_matrix(char **matrix, int **rez, int n, char map[3]);
void	ft_fill_x(char **matrix, int max, int max_i, int max_j);
void	ft_find_square(char **matrix, int **rez, int n, int m);
void	ft_print_matrix(char **matrix);
void	ft_find_matrix_square(char **matrix, char map[3]);
int		ft_validate(char **matrix, char map[3]);
void	ft_open_read(char *filename, char **str);
int		ft_run_matrix(char *filename);
char	*ft_read_input(void);
char	**ft_create_input_matrix(void);
int		ft_run_matrix_input(void);

#endif
