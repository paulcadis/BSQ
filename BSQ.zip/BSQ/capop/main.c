/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: capop <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/25 14:42:24 by capop             #+#    #+#             */
/*   Updated: 2016/07/27 19:19:37 by capop            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		main(int argc, char **argv)
{
	int i;

	i = 1;
	if (argc > 1)
	{
		while (i < argc)
		{
			if (ft_run_matrix(argv[i]) == 0)
				ft_putstr("map error\n");
			i++;
		}
	}
	else
	{
		if (ft_run_matrix_input() == 0)
			ft_putstr("map error\n");
	}
	return (0);
}
